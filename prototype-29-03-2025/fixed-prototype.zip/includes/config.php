<?php
// File: includes/config.php

// Define base URL for the application
$base_url = '/prototype/';
// Database connection configuration

// Database credentials
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "rolsa_technologies_db";
?>