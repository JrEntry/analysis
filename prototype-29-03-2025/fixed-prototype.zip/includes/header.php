<?php
// File: includes/header.php
// Common header for all pages
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ROLSA Technologies - Green Energy Solutions</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
  
  <!-- Custom CSS -->
  <link href="/assets/css/index.css" rel="stylesheet">
  <link href="/assets/css/app.css" rel="stylesheet">


  <!-- had to add inline styles because for some reason code was not being found and bootstrap was using its default -->
  <style>
    .btn-yellow-rolsa {
      background-color: #ECA400 !important;
      color: #16262E !important;
    }

    .btn-dark-rolsa {
      background-color: #16262E !important;
      color: white !important;
    }
  </style>

</head>

<body>
  <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg bg-rolsa py-3">
    <div class="container">

      <img src="/assets/images/logo.png" alt="Rolsa Technologies Logo" class="img-fluid" />


      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link text-dark-rolsa fw-medium mx-lg-3" href="/index.php"><i class="fas fa-home"></i> Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark-rolsa fw-medium mx-lg-3" href="/about.php"><i class="fas fa-info-circle"></i>
              About Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark-rolsa fw-medium mx-lg-3" href="/why-green.php"><i class="fas fa-leaf"></i> Why
              Go Green?</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark-rolsa fw-medium mx-lg-3" href="/services.php"><i class="fas fa-cogs"></i>
              Services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark-rolsa fw-medium mx-lg-3" href="/calculate.php"><i class="fas fa-calculator"></i>
              Calculate Impact</a>
          </li>
        </ul>
        <div class="d-flex">
          <a href="/auth/login.php" class="btn btn-yellow-rolsa me-2"><i class="fas fa-user"></i> My Account</a>
          <a href="#" class="btn btn-dark-rolsa"><i class="fas fa-calendar-check"></i> Book A Consultation</a>
        </div>
      </div>
    </div>
  </nav>